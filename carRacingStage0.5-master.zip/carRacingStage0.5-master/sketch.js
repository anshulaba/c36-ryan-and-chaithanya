var database, backgroundimg,canvas;
var gameState=0;
var playerCount;

var form,player,game;

function setup()
{
 canvas = createCanvas(400,400);
 database = firebase.database();
}

function draw()
{

}